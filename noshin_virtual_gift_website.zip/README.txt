# For Noshin ♡ — virtual gift website

## Preview on your device
Open `index.html` in a browser. For a better local preview, use a code editor's live preview.

## Personalize before publishing
- Edit the love letter inside the `<div class="letter" id="loveLetter"> ... </div>` section in `index.html`.
- Replace the sample secret-message text in the `data-message="..."` attributes.
- Set the birthday date in the website after opening it.
- To make photos and music appear for Noshin online, add image/audio files to the project and reference them in the HTML, or use media URLs you are allowed to share. The upload preview controls are local to the device/browser and do not upload files to the website.

## Publish free with GitHub Pages
1. Sign in or create a GitHub account.
2. Create a new public repository, for example `noshin-gift`.
3. Upload `index.html` to the repository's top/root folder. If adding photos/audio, upload those files too.
4. In the repository, open **Settings → Pages**.
5. Under the build/deployment source, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
6. Wait for the deployment to finish. GitHub will show a URL like `https://YOUR-USERNAME.github.io/noshin-gift/`.
7. Open that URL on your phone to test it, then send the link to Noshin.

Note: GitHub Pages is free for public repositories. Do not upload private information or photos without consent. Test the link in a private/incognito window before sharing.
